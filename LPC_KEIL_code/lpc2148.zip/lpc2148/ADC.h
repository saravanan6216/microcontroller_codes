#include<LPC214x.h>
unsigned int my_data;
unsigned int ADC()
{
	
	PINSEL0|=0x00300;
	
	AD0CR=0x00000000;
	AD0CR|=(0x01<<6);
	AD0CR|=13<<8;
	AD0CR|=0x01<<16;
	AD0CR|=0x01<<21;
	
	
	AD0CR|=0x01<<24;
	delay_ms(2);
	while((AD0GDR&(0x01<<31))==0)
		;
	
	my_data=AD0GDR;
	my_data=(my_data>>6)&0x3FF;
	return my_data;
}


